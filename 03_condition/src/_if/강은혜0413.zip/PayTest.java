package _if;

import java.text.DecimalFormat;
import java.util.Scanner;

public class PayTest {
	public static void main(String[] args) {
	
	String name; //이름
	String title; //직급
	int basePay; // 기본급
	int extraPay; // 수당
	double rate; //세율
	
	
	
	Scanner sc = new Scanner(System.in);
	System.out.print("이름 입력 : ");
	name = sc.next();
	System.out.print("직급 입력 : ");
	title = sc.next();
	System.out.print("기본급 입력 : ");
	basePay = sc.nextInt();
	System.out.print("수당 입력 : ");
	extraPay = sc.nextInt();
	
	int pay = basePay + extraPay; // 급여 = 기본급 + 수당
	if( pay > 4_000_000) rate=0.03; 
	else rate = 0.02;
	
	int tax = (int)(pay * rate); // 세금 = 급여 * 세율
	int salary = pay - tax; // 월급 = 급여 - 세금
	
	DecimalFormat df = new DecimalFormat();
	System.out.printf("***%s 월급 명세서***%n",name);
	System.out.printf("직급 : %s%n%n",title);
	System.out.println("기본급 \t 수당 \t  급여 \t 세율 \t  세금 \t 월급");
	System.out.println(df.format(basePay) +" "+ df.format(extraPay) + " "+ df.format(pay) +" "+  (int)(rate*100) + "% "+ df.format(tax) + " "+ df.format(salary));
	
	
	}
}
