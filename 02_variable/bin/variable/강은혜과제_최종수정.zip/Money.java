package variable;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Money {
	public static void main(String[] args) {
		 
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("money입력>> ");
		int num = scanner.nextInt();
		System.out.println();
		
		DecimalFormat df = new DecimalFormat();
		System.out.printf("money : " + df.format(num)+"원%n");
		System.out.printf("천의자리%d원%n",num/1000);
		num = num%1000;
		System.out.printf("백의자리%d원%n",num/100);
		num = num%100;
		System.out.printf("십의자리%d원%n",num/10);
		num = num%10;
		System.out.printf("일의자리%d원%n",num);
		System.out.println();
		
		
	
		
		
		
		
		
		
		
		
	}
}
